import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h1>RG Yojana Connect</h1>
      <p>Your Yojana, Your Doorstep</p>
      <p>भारत की सभी सरकारी योजनाएं, अब आपके द्वार</p>
    </div>
  );
}

export default App;
